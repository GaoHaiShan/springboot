document.write("<script src=\"https://s13.cnzz.com/z_stat.php?id=1271767266&web_id=1271767266\" language=\"JavaScript\"></script>");
