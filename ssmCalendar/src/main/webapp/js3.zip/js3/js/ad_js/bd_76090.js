if ((navigator.userAgent.match(/(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone)/i))) { 
    document.write("<script type=\"text/javascript\">google_ad_client = \"ca-pub-7515443544894528\";google_ad_slot = \"8321126704\";google_ad_width = 300;google_ad_height = 250;</script>");
	document.write("<script type=\"text/javascript\" src=\"//pagead2.googlesyndication.com/pagead/show_ads.js\"></script>");
}else{ 
    //document.write("<script type=\"text/javascript\">google_ad_client = \"ca-pub-7515443544894528\";google_ad_slot = \"3438097725\";google_ad_width = 728;google_ad_height = 90;</script>");
	//document.write("<script type=\"text/javascript\" src=\"//pagead2.googlesyndication.com/pagead/show_ads.js\"></script>");
document.write('<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
document.write('<ins class="adsbygoogle"');
document.write('style="display:inline-block;width:728px;height:90px"');
document.write('data-ad-client="ca-pub-7515443544894528"');
document.write('data-ad-slot="3438097725"></ins>');
document.write('<script>');
document.write('(adsbygoogle = window.adsbygoogle || []).push({});');
document.write('</script>');
} 
